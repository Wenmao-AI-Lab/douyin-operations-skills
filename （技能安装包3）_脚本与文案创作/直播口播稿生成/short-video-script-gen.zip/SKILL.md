---
name: short-video-script-gen
description: 输入产品、主题或平台，一键生成可拍摄的爆款脚本六件套，并交付结构化HTML拍摄卡。适用于抖音、视频号、小红书带货与知识博主，把"拆解别人爆款"升级为"造自己的爆款"。触发：写短视频脚本、拍抖音、做分镜表、口播稿、爆款标题、种草视频、带货话术、视频号脚本。
slug: short-video-script-gen
displayName: "短视频爆款脚本·AI分镜生成"
display_name: "短视频爆款脚本·AI分镜生成"
display_name_en: "Viral Short-Video Script Generator"
description_en: "Turn any product or topic into a shoot-ready package—hook, script, shot list, voiceover, titles and cover copy—delivered as a structured HTML shooting card. Built for Douyin, WeChat Channels and Xiaohongshu creators who want to make hits, not just dissect other people's."
tags:
  - "短视频"
  - "脚本生成"
  - "内容创作"
  - "分镜脚本"
  - "爆款工厂"
category: "content-creation"
version: "1.0.0"
---


# 短视频爆款脚本·AI分镜生成

> **一句话定位**：你说卖什么 / 讲什么 → 我给你一套能直接开拍的「选题+脚本+分镜+口播+标题+封面文案」六件套，并交付一张可打印的 HTML 拍摄卡。市面上的同类只会"拆解别人的爆款"，这个直接"帮你造自己的爆款"。

## 触发条件

| 触发词 | 示例 |
|--------|------|
| 写短视频脚本 / 拍抖音 | "帮我写一条卖防晒霜的抖音脚本" |
| 做分镜表 / 口播稿 | "把这个知识点做成 60 秒口播，给分镜" |
| 爆款标题 / 封面文案 | "给我 5 个能点的标题和封面文案" |
| 种草视频 / 带货话术 | "拍个小红书种草视频，要带货感" |
| 视频号脚本 | "视频号适合发什么内容，给个脚本" |

## 核心能力

- 🎯 **爆款选题**：按平台调性生成 3 个差异化切入点，附预估完播逻辑
- 📝 **结构化脚本**：黄金 3 秒钩子 → 痛点 → 价值 → 行动，分段带时长
- 🎬 **分镜表**：每屏画面 / 景别 / 字幕 / 机位，导演可直接执行
- 🎙️ **口播稿**：口语化、有节奏、带停顿标记，照读即出片
- 🏷️ **标题矩阵**：5 条标题（悬念 / 数字 / 反差 / 利益 / 情绪）任选
- 🖼️ **封面文案**：4 字以内主标 + 副标，适配平台封面比例

## 执行流程

### Step 1：锁定输入与平台

向用户确认（缺失则默认并标注）：
1. **品类/主题**：产品名、卖点、或要讲的知识点
2. **目标平台**：抖音 / 视频号 / 小红书（默认抖音）
3. **时长**：15s / 30s / 60s / 3min（默认 60s）
4. **人设/调性**：专业测评 / 闺蜜种草 / 硬核科普 / 搞笑（默认种草）

### Step 2：选题爆破（必产出 3 选 1+）

每个选题给出：`切入点` + `为什么能火（完播/共鸣/稀缺）` + `风险点`。
规则：
- 不抄热点标题，做"热点角度的二创"
- 每条选题必须指向一个**具体观众情绪**（焦虑/好奇/爽感/认同）

### Step 3：脚本四段式（强制结构）

```
[0-3s]  钩子：反常识 / 直接利益 / 悬念提问
[3-15s] 痛点：用户正在经历的麻烦（具象场景）
[15-50s] 价值：你的方法 / 产品如何解决问题（演示或论证）
[50-60s] 行动：关注 / 评论关键词 / 下单指引（单一指令）
```

### Step 4：分镜表（每 5-10 秒一镜）

| 时间 | 画面描述 | 景别 | 字幕 | 机位/动作 |
|------|---------|------|------|----------|
| 0-3s | 手持产品怼脸，皱眉 | 近景 | "你还在这样用？" | 固定 |
| 3-8s | 对比错误用法 | 中景 | "90%人都错" | 横移 |

### Step 5：口播稿 + 标题 + 封面

口播稿用 **口语短句**，每句 ≤ 15 字，标注 `[停顿]` `[重音]`。
标题矩阵 5 条，封面文案主标 ≤ 4 字。

### Step 6：HTML 拍摄卡（必须交付）

文件命名：`{主题}_{平台}_拍摄卡_{YYYYMMDD}.html`，保存至用户工作目录，UTF-8 自包含。

```html
<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<title>{主题} 拍摄卡</title>
<style>
:root{--bg:#0f1115;--card:#1c1f26;--acc:#ff2e4d;--txt:#f5f5f5;--mut:#9aa0aa;}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--txt);max-width:900px;margin:0 auto;padding:24px;}
.card{background:var(--card);border-radius:14px;padding:18px 20px;margin-bottom:14px;box-shadow:0 4px 16px rgba(0,0,0,.35);}
h1{font-size:24px;margin:0 0 4px;} .sub{color:var(--mut);font-size:13px;margin-bottom:16px;}
.tag{display:inline-block;background:var(--acc);color:#fff;border-radius:6px;padding:2px 8px;font-size:12px;margin-right:6px;}
table{width:100%;border-collapse:collapse;font-size:13px;} th,td{border:1px solid #2c3038;padding:8px;text-align:left;}
th{background:#262b34;color:var(--mut);} .hook{color:var(--acc);font-weight:700;}
</style></head><body>
<div class="card"><h1>{主题} · {平台}拍摄卡</h1><div class="sub">{时长} · {人设} · {日期}</div>
<span class="tag">选题A</span><span class="tag">选题B</span><span class="tag">选题C</span></div>
<div class="card"><h3>🎯 选定选题</h3><p>{切入点} — {火的逻辑}</p></div>
<div class="card"><h3>📝 脚本四段</h3>
<p class="hook">[0-3s] 钩子：{钩子}</p><p>[3-15s] 痛点：{痛点}</p>
<p>[15-50s] 价值：{价值}</p><p>[50-60s] 行动：{行动}</p></div>
<div class="card"><h3>🎬 分镜表</h3>
<table><tr><th>时间</th><th>画面</th><th>景别</th><th>字幕</th><th>机位</th></tr>
<tr><td>0-3s</td><td>{画面}</td><td>{景别}</td><td>{字幕}</td><td>{机位}</td></tr></table></div>
<div class="card"><h3>🎙️ 口播稿</h3><p>{逐句口播，带[停顿][重音]}</p></div>
<div class="card"><h3>🏷️ 标题矩阵</h3><p>1.{悬念} 2.{数字} 3.{反差} 4.{利益} 5.{情绪}</p></div>
<div class="card"><h3>🖼️ 封面</h3><p>主标：{≤4字} ｜ 副标：{副标}</p></div>
</body></html>
```

## 输出规范

- **对话输出**：精选摘要（≤40 行）—— 选定选题 + 脚本四段要点 + 标题 5 选 + HTML 路径。
- **HTML 拍摄卡**：必须生成并告知路径，用户可直接打印/分享。
- 禁止在对话堆砌完整分镜原文；详情看 HTML。

## Pay Skill 预留

> 个人创作者计费通道上线后直接升级计费。

本 skill 未来可开放：免费版每日 3 条脚本；Pro 版无限次 + 多平台一键适配 + A/B 标题测爆；团队版品牌脚本库。

## 免责声明

- 生成内容仅供参考与创作辅助，不承诺播放量或转化效果。
- 涉及产品宣传须遵守《广告法》，不得虚假宣传；医疗/金融等特殊品类需资质。
- 用户对自身发布内容负全部责任。