<!-- 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect -->

# 拆解经验沉淀库（Dissect Lessons）



> 本文件由 `scripts/record_dissect_lesson.py` 或手动 append-only 写回。每次拆解暴露的**可复用、类型作用域内**教训都在此累积。

> 与 `references/cross_video_insight.md`（多视频聚合）形成「单次写回 + 多视频提炼」双通道。

> 记录格式：`- <YYYY-MM-DD> / 类型: <...> / lesson: <...> / evidence: <...> / action: <...>`



## Accumulated Lessons



### 短视频手艺展示（ASMR / 布线 / 监控 / 收纳）

- 2026-07-31 / source: 布线大师啊合作 / lesson: 金句横幅（如"外行看热闹内行看门道"）是最大转发引擎 / evidence: D9社交链适配度=4.5 / action: 二创必加黄字金句横幅

- 2026-07-31 / source: 布线大师啊 / lesson: "乱→有序"ASMR 闭环是完播率核心，20s 内完成 / evidence: 完播率高（推测） / action: 手艺类二创保持闭环结构

- 2026-07-31 / source: 布线大师啊 / lesson: 金钱锚定尾钩（"一天800""千八百"）驱动评论 / evidence: 互动设计短板时尤其有效 / action: 结尾给具体数字

- 2026-07-31 / source: 监控大师啊（用户自写） / lesson: 系列化复制（换工种即量产）可行，骨架继承俗语钩子+6步+尾钩 / evidence: 用户文案天然踩中 / action: 同系列换内容填模板



### 口播观点 / 干货

- 2026-07-31 / source: 多视频 / lesson: 互动钩子必须有，否则完播高但评论低 / evidence: 布线大师啊互动=3.0 短板 / action: 二创结尾必加提问钩子



### 品牌故事 / 企业叙事

- 2026-07-31 / source: 极狐V9 / 华为坤灵 / lesson: 可复制性常低（硬信用门槛），二创需轻量化改编 / action: 给低成本替代而非照搬

- 2026-07-31 / source: 谢康校长 / lesson: 延迟身份揭示（先讲故事再亮姓名条）强信任 / evidence: 第9分钟揭示校长身份 / action: 长视频可用此法



### 人物纪录 / 访谈

- 2026-07-31 / source: 谢康校长 / lesson: 多幕结构 + 真实素材（校园/B-roll）是人物片骨架 / action: 二创用案例素材转译到自身赛道



### 热点混剪 / 盘点

（待累积）



### 平台规则

- 2026-07-31 / source: 布线大师啊双发 / lesson: 二次发布查重降权，初始池缩 50–80% / evidence: 90w→3.5w 实证 / action: 重发必先去重改造或升级为"复盘"二创

- 2026-07-31 / source: 同上 / lesson: 社交图疲劳是冷启动失败次因 / evidence: 涨粉率 0.54%→0.26% / action: 一年后重发效果必衰减



### 通用（跨类型）

- 2026-07-31 / source: 极狐误判纠正 / lesson: 屏幕文字优先（专名 ground truth），与 ASR 冲突以画面为准 / action: 抽帧后强制读字层

- 2026-07-31 / source: 多视频 / lesson: 长视频(>3min) 场景检测必开，否则漏关键幕 / action: 长视频强制场景检测

- 2026-08-03 / source: 技能增强 / lesson: 每次运行写「本次运行证据」节，标注推测/降级，提升可信度 / action: 报告必含证据节

