<!-- 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect -->

# 技能地图（Index · 你在哪、该去哪）



> 本技能文献较多（26 篇 references）。这份地图帮你**30 秒定位**需要的那篇，不用瞎翻。

> 原则：**你只需用人话跟 AI 说需求，AI 会自己调这些文件。本地图是给你"想深究某个点"时查的。**



---



## 📍 先看这层：三层阅读路径（别一头扎进 26 篇里）



| 层 | 读什么 | 读多久 | 什么时候读 |

|----|--------|--------|-----------|

| **L1 速通** | **`skill_overview.md`** | **5 分钟** | **第一次用 / 赶时间 / 想快速回忆全貌** |

| L2 完整 | `SKILL.md`（1041 行，九大步骤全展开） | 30 分钟 | 真要深用、要改流程、要核对细节 |

| L3 专题 | 下面第二节的 26 篇 | 按需 | 遇到具体问题（钩子 / 文案 / BGM / 合规…） |



> **大多数人读 L1 就够了。** L1 里有九步地图、跳过规则、四道决策门、术语速查，读完能上手 80% 的场景。



---



## 一、5 大入口 × 对应文献



> 🚀 **0 号入口（新增）**：赶时间 / 第一次用 → 直接读 `skill_overview.md`（5 分钟速通，含九步地图 + 跳过规则矩阵 + 四道决策门 + 术语速查）。下面 ①–⑤ 是"已经知道要干什么、要深究细节"时再查。



| 你想做的事 | 走哪条线 | 核心文献（按需深读） |

|------------|----------|----------------------|

| **① 只有一句话想法，要选题/标题** | 轻量选题线（步骤 0.5） | `lightweight_ideation.md`（五钩子/标题规则/去AI味/批量出题） |

| **② 有爆款视频，要拆解 + 二创脚本** | 主流程（步骤 1–8） | `script_template.md`（分镜/发布包装/BGM）、`framework_rubric.md`（钩子库）、`copywriting_craft.md`（文案雕琢）、`bgm_design.md`（配乐） |

| **③ 有自己的视频，要 8 维找短板** | 八维自分析（步骤 0 确认门） | `skill-self-check.md`（健康自检）、`type_failure_playbook.md`（类型翻车预案）、`tone_expression_rubric.md`（语气感染力） |

| **④ 发布前怕违规/限流** | 合规检测门（步骤 6.5） | `compliance_checklist.md`（8 类词库）、`platform_rules.md`（四平台红线） |

| **⑤ 想建/查选题库** | 选题库沉淀（步骤 7） | 工作区 `video-script-dissect_选题库/`（结构化 JSON + MD） |



---



## 二、按主题找文献



**钩子 / 开头怎么设计**

- `framework_rubric.md` —— 16 种开篇钩子句式 + 六维钩子扫描法

- `b2b_hook_formulas.md` —— B 端工厂开头公式（你信不信/真没想到/想想都可怕/千万不要）

- `lightweight_ideation.md` —— 五钩子出题（反常识/数字冲击/刺痛共鸣/反问抬杠/揭秘内幕）



**文案怎么写 / 去 AI 味**

- `copywriting_craft.md` —— 文案雕琢、价值升华三法、去AI味词库

- `tone_expression_rubric.md` —— 语气表情感染力、人设口吻



**分镜 / 拍摄 / BGM**

- `script_template.md` —— 镜头表、发布包装模板、四类叙事结构、成本优先级

- `shooting_techniques.md` —— 拍摄手法库

- `bgm_design.md` —— BGM 曲风/配器/音量曲线/AI音乐指令

- `visual_analysis.md` —— 抽帧视觉分析规范



**八维 / 结构框架**

- `skill-self-check.md` —— 8 维评分表 + 健康自检

- `cross_video_insight.md` —— 跨视频共同框架提炼

- `audience_profile.md` —— 受众画像

- `plan_schema.md` —— 排期矩阵 schema



**合规 / 平台**

- `compliance_checklist.md` —— 违禁词 8 类 + 三段式回执模板

- `platform_rules.md` —— 视频号/抖音/小红书/公众号四平台红线速查



**经验 / 踩坑**

- `dissect-lessons.md` —— 拆解实战教训沉淀

- `extraction_enhancements.md` —— 视频抓取/逐字稿提取增强（含视频号闭环限制说明）



---



## 三、遇到问题先翻哪



| 症状 | 去哪 |

|------|------|

| 视频抓不到 / 模型下载慢 | `faq.md` 第 1、2 条 |

| 只想出题不想拆解 | `faq.md` 第 3 条 / `lightweight_ideation.md` |

| 违禁词命中 | `faq.md` 第 4 条 / `compliance_checklist.md` |

| 要不要进选题库 | `faq.md` 第 5 条 |

| 八维 vs 二创 选错 | `faq.md` 第 6 条 |

| 段印/封印报错 | `faq.md` 第 7 条 |

| 脚本看不懂怎么拍 | `faq.md` 第 8 条 / `script_template.md` |

| 不知道从哪开始 | `faq.md` 第 0 条 / 本地图第一节 |



---



## 四、版本与维护



- 当前版本见 `SKILL.md` frontmatter `version` 字段，变更历史见 `CHANGELOG.md`。

- 本技能带内容指纹（段印 `DYSEAL-471BDA64D4A87936`），文献被改须重签，详见 `faq.md` 第 7 条。

<!-- 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect -->

