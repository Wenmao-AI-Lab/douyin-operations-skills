# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect

# 本文件为「段印(DUANYIN-SEAL)」防伪封签的运行内核，受 SEAL.json 签名保护。

# 未经作者授权修改本文件将导致签名校验失败（tamper-evident）。

import os

import sys

import json

import hashlib

import base64

import pathlib



SEAL_TOKEN = "XIAODUAN-SEAL"

FINGERPRINT = "DYSEAL-471BDA64D4A87936"

OWNER = "安粉传媒·小段"

SKILL_ID = "video-script-dissect"

EXPECTED_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----

MCowBQYDK2VwAyEAa/Wk3KvJa0CTG9LqhoHeHXZ21if2SNtdU0ncBFtgQYs=

-----END PUBLIC KEY-----

"""



SKILL_DIR = pathlib.Path(__file__).resolve().parent.parent

SEAL_FILE = SKILL_DIR / "SEAL.json"





def _cryptography():

    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    from cryptography.hazmat.primitives import serialization

    return Ed25519PublicKey, serialization





def file_sha256(path):

    h = hashlib.sha256()

    with open(path, "rb") as f:

        for chunk in iter(lambda: f.read(65536), b""):

            h.update(chunk)

    return h.hexdigest()





def verify_signature(pub_pem, manifest_hash, sig_b64):

    try:

        Ed25519PublicKey, serialization = _cryptography()

        key = serialization.load_pem_public_key(pub_pem.encode("utf-8"))

        key.verify(base64.b64decode(sig_b64), manifest_hash.encode("utf-8"))

        return True

    except Exception:

        return False





def verify_seal(verbose=True):

    problems = []

    if not SEAL_FILE.exists():

        problems.append("SEAL.json 缺失：本技能未被封印或文件已丢失")

        return False, problems

    try:

        seal = json.loads(SEAL_FILE.read_text(encoding="utf-8"))

    except Exception as e:

        return False, ["SEAL.json 解析失败：" + str(e)]



    # 1) 身份锚点（与硬编码常量比对）

    if seal.get("fingerprint") != FINGERPRINT:

        problems.append("指纹不符：可能被克隆或替换")

    if seal.get("skill_id") != SKILL_ID:

        problems.append("技能ID不符：可能被冒用")

    if seal.get("public_key", "").strip() != EXPECTED_PUBLIC_KEY.strip():

        problems.append("公钥不符：封印签名密钥被替换")



    # 2) 文件哈希

    manifest = seal.get("manifest", {})

    for rel, expect in manifest.items():

        p = SKILL_DIR / rel

        if not p.exists():

            problems.append(f"文件缺失：{rel}")

            continue

        actual = file_sha256(p)

        if actual != expect:

            problems.append(f"文件被改动：{rel}")



    # 3) 签名

    try:

        pub = seal.get("public_key", "")

        mh = seal.get("manifest_hash", "")

        sig = seal.get("signature", "")

        if not verify_signature(pub, mh, sig):

            problems.append("签名校验失败：SEAL.json 被篡改（cryptography 缺失则跳过）")

    except Exception as e:

        problems.append(f"签名校验跳过（cryptography 缺失）：{e}")



    # 4) 水印

    missing_wm = []

    for rel in manifest:

        if not rel.endswith((".md", ".py", ".html")):

            continue

        p = SKILL_DIR / rel

        if p.exists() and SEAL_TOKEN not in p.read_text(encoding="utf-8", errors="ignore"):

            missing_wm.append(rel)

    if missing_wm:

        problems.append("水印缺失：" + ", ".join(missing_wm))



    ok = len(problems) == 0

    if verbose:

        if ok:

            print(f"✅ 段印完好 · {FINGERPRINT} · {OWNER}")

        else:

            print("⛔ 段印告警：")

            for pr in problems:

                print("  - " + pr)

    return ok, problems





if __name__ == "__main__":

    ok, _ = verify_seal()

    sys.exit(0 if ok else 1)

