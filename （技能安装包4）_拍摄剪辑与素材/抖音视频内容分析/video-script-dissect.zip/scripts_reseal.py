# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect

# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-7F57D063982444F7 · duanyin-seal

# 段印重封（仅作者/持有私钥者可用 · 通用）

import sys

import json

import hashlib

import base64

from pathlib import Path



# 私钥路径：环境变量优先，默认值 fallback（向后兼容）。

# 不再硬编码用户主目录下的持久敏感路径——持有者可用环境变量把私钥放在任意位置（加密卷/USB Key 等）。

import os



_SECRETS_DIR = Path(os.environ.get(

    "DUANYIN_SECRETS_DIR",

    str(Path.home() / ".aibox" / "skills" / ".secrets"),

))

PRIV = Path(os.environ.get(

    "DUANYIN_OWNER_KEY_PATH",

    str(_SECRETS_DIR / "duanyin_seal_owner_ed25519.pem"),

))

SKILL_DIR = Path(__file__).resolve().parent.parent





def sign(priv_pem, mh):

    from cryptography.hazmat.primitives import serialization

    key = serialization.load_pem_private_key(priv_pem.encode(), password=None)

    return base64.b64encode(key.sign(mh.encode())).decode()





def main():

    if not PRIV.exists():

        sys.stderr.write("⛔ 未找到作者私钥：%s\n" % PRIV)

        sys.stderr.write("可通过环境变量自定义私钥位置，例如：\n")

        sys.stderr.write("  Windows: set DUANYIN_OWNER_KEY_PATH=D:\\keys\\owner.pem\n")

        sys.stderr.write("  Linux/Mac: export DUANYIN_OWNER_KEY_PATH=/root/keys/owner.pem\n")

        sys.stderr.write("（密钥请勿进 git / 请勿随技能包分发）\n")

        sys.exit(2)

    priv = PRIV.read_text(encoding="utf-8")

    seal_path = SKILL_DIR / "SEAL.json"

    seal = json.loads(seal_path.read_text(encoding="utf-8"))

    manifest = {}

    for rel in seal["manifest"].keys():

        p = SKILL_DIR / rel

        if p.exists():

            manifest[rel] = hashlib.sha256(p.read_bytes()).hexdigest()

    canon = json.dumps(manifest, sort_keys=True, ensure_ascii=False)

    mh = hashlib.sha256(canon.encode()).hexdigest()

    sig = sign(priv, mh)

    seal["manifest"] = manifest

    seal["manifest_hash"] = mh

    seal["signature"] = sig

    seal_path.write_text(json.dumps(seal, ensure_ascii=False, indent=2), encoding="utf-8")

    print("✅ 已重封 ·", seal.get("fingerprint"))





def _check_isolated_venv():

    """拒绝在系统 Python 中执行，强制要求隔离 venv。"""

    if sys.prefix == sys.base_prefix:

        sys.stderr.write(

            "⛔ 必须在隔离 venv 内运行（拒绝系统 Python）。\n"

            "请使用：技能包指定的隔离 Python 环境（envs/default）\n"

        )

        raise SystemExit(4)





if __name__ == "__main__":

    _check_isolated_venv()

    main()

