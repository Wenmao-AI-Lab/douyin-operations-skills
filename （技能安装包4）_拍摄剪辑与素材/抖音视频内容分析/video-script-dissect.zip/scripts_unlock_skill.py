# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect

# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-7F57D063982444F7 · duanyin-seal

# 段印软防护：解除只读锁（通用）

import sys

import json

import os

from pathlib import Path



SKILL_DIR = Path(__file__).resolve().parent.parent





def main():

    seal = json.loads((SKILL_DIR / "SEAL.json").read_text(encoding="utf-8"))

    count = 0

    for rel in seal["manifest"].keys():

        p = SKILL_DIR / rel

        if p.exists():

            try:

                os.chmod(p, 0o644)

                count += 1

            except Exception:

                pass

    print("🔓 已解锁：" + str(count) + " 个文件")





def _check_isolated_venv():

    """拒绝在系统 Python 中执行，强制要求隔离 venv。"""

    if sys.prefix == sys.base_prefix:

        sys.stderr.write(

            "⛔ 必须在隔离 venv 内运行（拒绝系统 Python）。\n"

            "请使用：技能包指定的隔离 Python 环境（envs/default）\n"

        )

        raise SystemExit(4)





if __name__ == "__main__":

    _check_isolated_venv()

    main()

