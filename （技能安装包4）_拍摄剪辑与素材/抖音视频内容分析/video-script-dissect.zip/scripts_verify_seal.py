# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-471BDA64D4A87936 · video-script-dissect

# 段印 · 安粉传媒·小段专属 · XIAODUAN-SEAL · DYSEAL-7F57D063982444F7 · duanyin-seal

# 段印运行校验入口（通用 · 复制到目标技能后无需改动）

import sys

from pathlib import Path



sys.path.insert(0, str(Path(__file__).resolve().parent))

import duanyin_seal



def _check_isolated_venv():

    """拒绝在系统 Python 中执行，强制要求隔离 venv。"""

    if sys.prefix == sys.base_prefix:

        sys.stderr.write(

            "⛔ 必须在隔离 venv 内运行（拒绝系统 Python）。\n"

            "请使用：技能包指定的隔离 Python 环境（envs/default）\n"

        )

        raise SystemExit(4)





if __name__ == "__main__":

    _check_isolated_venv()

    ok, _ = duanyin_seal.verify_seal()

    sys.exit(0 if ok else 1)

