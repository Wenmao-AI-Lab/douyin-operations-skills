# -*- coding: utf-8 -*-

"""

抖音无水印下载器 - 核心脚本

下载原理：

  1. 提取分享链接 -> 跟随301重定向 -> 获取真实URL

  2. 解析video_id

  3. 请求 https://www.iesdouyin.com/share/video/{video_id}/

  4. 从 window._ROUTER_DATA JSON 中提取 uri

  5. 构造无水印下载地址：https://www.douyin.com/aweme/v1/play/?video_id={uri}

"""

import sys

import os



# 自动安装依赖（仅通过 requirements.txt + --require-hashes，防止供应链投毒）

try:

    import requests

except ImportError:

    import subprocess

    _req_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "requirements.txt")

    if os.path.exists(_req_file):

        print("[*] 检测到缺少 requests 库，正在通过 requirements.txt 安装（SHA256 hash 校验）...")

        subprocess.run(

            [sys.executable, "-m", "pip", "install", "-r", _req_file, "--require-hashes", "-q"],

            check=True,

        )

    else:

        print("[!] 错误：未找到 requirements.txt，无法安全安装依赖。")

        print("    请手动执行：pip install -r requirements.txt --require-hashes")

        sys.exit(1)

    import requests



import re

import json



HEADERS = {

    "User-Agent": (

        "Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) "

        "AppleWebKit/537.36 (KHTML, like Gecko) "

        "Chrome/116.0.0.0 Mobile Safari/537.36"

    ),

    "Referer": "https://www.douyin.com/?is_from_mobile_home=1&recommend=1",

}





def extract_url(text: str) -> str | None:

    """从分享文本中提取抖音链接（短链或长链）"""

    m = re.search(r"https?://v\.douyin\.com/[a-zA-Z0-9\-_.]+", text)

    if m:

        url = m.group(0)

        return url if url.endswith("/") else url + "/"

    m = re.search(r"https?://(?:www\.)?douyin\.com/(?:video|note)/[0-9]+", text)

    if m:

        return m.group(0)

    return None





def get_real_url(share_url: str) -> str | None:

    """跟随重定向，获取真实URL（含video_id）"""

    if "douyin.com/video/" in share_url or "douyin.com/note/" in share_url:

        return share_url

    try:

        r = requests.get(share_url, headers=HEADERS, allow_redirects=True, timeout=10)

        return r.url

    except Exception as e:

        print(f"[!] 获取真实链接失败: {e}")

        return None





def get_video_id(url: str) -> str | None:

    """从URL中提取视频ID"""

    for param in ["modal_id", "note_id", "item_id", "video_id"]:

        m = re.search(rf"{param}=([0-9]+)", url)

        if m:

            return m.group(1)

    m = re.search(r"/(?:video|note|share/video)/([0-9]+)", url)

    if m:

        return m.group(1)

    m = re.search(r"/([0-9]{15,})", url)

    if m:

        return m.group(1)

    return None





def get_video_data(video_id: str) -> dict | None:

    """请求详情页并解析 _ROUTER_DATA JSON"""

    url = f"https://www.iesdouyin.com/share/video/{video_id}/"

    try:

        r = requests.get(url, headers=HEADERS, timeout=15)

        r.raise_for_status()

        m = re.search(r"window\._ROUTER_DATA\s*=\s*(.*?)</script>", r.text, re.DOTALL)

        if m:

            return json.loads(m.group(1).strip())

        print("[!] 页面中未找到 _ROUTER_DATA")

        return None

    except Exception as e:

        print(f"[!] 获取视频数据失败: {e}")

        return None





def parse_video_info(data: dict) -> dict | None:

    """从JSON数据中提取视频信息和无水印下载地址"""

    try:

        loader_data = data.get("loaderData", {})

        video_info_res = None

        for key, value in loader_data.items():

            if isinstance(value, dict) and "videoInfoRes" in value:

                video_info_res = value["videoInfoRes"]

                break

        if not video_info_res:

            print("[!] 未找到 videoInfoRes")

            return None



        item_list = video_info_res.get("item_list", [])

        if not item_list:

            print("[!] item_list 为空")

            return None



        video_item = item_list[0]

        desc = video_item.get("desc", "无标题")

        nickname = video_item.get("author", {}).get("nickname", "未知作者")



        uri = video_item.get("video", {}).get("play_addr", {}).get("uri")

        if not uri:

            print("[!] 未找到视频 URI")

            return None



        download_url = f"https://www.douyin.com/aweme/v1/play/?video_id={uri}"

        return {

            "desc": desc,

            "nickname": nickname,

            "download_url": download_url,

        }

    except Exception as e:

        print(f"[!] 解析视频信息出错: {e}")

        return None





def download_video(url: str, filename: str) -> bool:

    """下载视频文件（流式，显示进度）"""

    try:

        print(f"[+] 正在下载: {os.path.basename(filename)}")

        r = requests.get(url, headers=HEADERS, stream=True, timeout=30)

        if r.status_code == 403:

            print("[~] 403，去掉Referer重试...")

            h2 = HEADERS.copy()

            h2.pop("Referer", None)

            r = requests.get(url, headers=h2, stream=True, timeout=30)

        r.raise_for_status()



        total = int(r.headers.get("content-length", 0))

        downloaded = 0

        with open(filename, "wb") as f:

            for chunk in r.iter_content(chunk_size=8192):

                if chunk:

                    f.write(chunk)

                    downloaded += len(chunk)

                    if total > 0:

                        pct = downloaded / total * 100

                        bar = "#" * int(pct / 2)

                        print(f"\r  [{bar:<50}] {pct:.1f}%", end="", flush=True)

        print()

        print(f"[OK] 下载完成！保存至: {os.path.abspath(filename)}")

        return True

    except Exception as e:

        print(f"[!] 下载失败: {e}")

        return False





def run(raw_input: str, output_dir: str = None) -> bool:

    """主流程：输入分享链接/文本，下载无水印视频"""

    # 默认保存到脚本所在目录

    if output_dir is None:

        output_dir = os.path.dirname(os.path.abspath(__file__))

    os.makedirs(output_dir, exist_ok=True)



    share_url = extract_url(raw_input)

    if not share_url:

        print(f"[!] 未在输入中找到有效链接: {raw_input}")

        return False



    print(f"[+] 正在解析链接: {share_url}")

    real_url = get_real_url(share_url)

    if not real_url:

        return False



    video_id = get_video_id(real_url)

    if not video_id:

        print("[!] 无法提取视频ID")

        return False



    print(f"[+] 视频ID: {video_id}")

    data = get_video_data(video_id)

    if not data:

        return False



    info = parse_video_info(data)

    if not info:

        return False



    print(f"[+] 视频: {info['desc']} | 作者: {info['nickname']}")



    safe_desc = re.sub(r'[\\/*?:"<>|\r\n\t]', "", info["desc"])[:30]

    filename = os.path.join(output_dir, f"{safe_desc}_{video_id}.mp4")

    return download_video(info["download_url"], filename)





def run_batch(txt_file: str, output_dir: str = None) -> None:

    """批量下载：从txt文件逐行读取链接"""

    if output_dir is None:

        output_dir = os.path.dirname(os.path.abspath(__file__))

    if not os.path.exists(txt_file):

        print(f"[!] 找不到文件: {txt_file}")

        return



    urls = []

    for enc in ("utf-8", "gbk", "utf-16"):

        try:

            with open(txt_file, "r", encoding=enc) as f:

                urls = [l.strip() for l in f if l.strip()]

            break

        except Exception:

            continue



    if not urls:

        print("[!] 文件中未找到有效链接")

        return



    total = len(urls)

    print(f"[+] 共 {total} 个链接，开始批量下载...")

    for i, url in enumerate(urls, 1):

        print(f"\n--- 第 {i}/{total} 个 ---")

        run(url, output_dir)





if __name__ == "__main__":

    # 脚本所在目录的上一级作为默认下载目录

    script_dir = os.path.dirname(os.path.abspath(__file__))

    skill_dir = os.path.dirname(script_dir)  # SKILL 根目录



    if len(sys.argv) < 2:

        print("用法:")

        print("  单个下载:  python download.py <分享链接或文本>")

        print("  批量下载:  python download.py --batch <txt文件路径> [保存目录]")

        print("  指定目录:  python download.py <链接> <保存目录>")

        print(f"  默认保存至: {skill_dir}")

        sys.exit(0)



    if sys.argv[1] == "--batch":

        txt = sys.argv[2] if len(sys.argv) > 2 else "links.txt"

        out = sys.argv[3] if len(sys.argv) > 3 else skill_dir

        run_batch(txt, out)

    else:

        link = sys.argv[1]

        out = sys.argv[2] if len(sys.argv) > 2 else skill_dir

        run(link, out)

